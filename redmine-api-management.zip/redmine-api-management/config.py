import os

EMAIL_ADDRESS = 'chamado@evolutionit.com.br'
EMAIL_PASSWORD = 'agua9999'
SMTP_SERVER = 'smtp.kinghost.net'
SMTP_PORT = 587
DOMAIN = 'evolutionit.com.br'
AUTH_METHOD = 'login'
ENABLE_STARTTLS_AUTO = True
OPENSSL_VERIFY_MODE = 'none'


REDMINE_URL = 'https://redmine5tec.evtit.com'
REDMINE_API_KEY = "ea8d896c01e60cbc31baf6e84e9d4bf8eee5033b"
#REDMINE_URL = os.getenv('REDMINE_URL')
#REDMINE_API_KEY = os.getenv('REDMINE_API_KEY')
